package top.niunaijun.blackboxa.view.setting

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import top.niunaijun.blackboxa.R
import top.niunaijun.blackboxa.databinding.ActivityNextdnsBinding
import top.niunaijun.blackboxa.nextdns.NextDnsVpnService

class NextDnsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNextdnsBinding
    private val preferences by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) connectNow() else showMessage("Izin VPN dibatalkan")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNextdnsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "NextDNS"

        binding.dnsInput.setText(preferences.getString(KEY_DNS, NextDnsVpnService.DEFAULT_DNS))
        binding.connectButton.setOnClickListener { requestConnect() }
        binding.disconnectButton.setOnClickListener { disconnectNow() }
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) refreshStatus()
    }

    private fun requestConnect() {
        val dns = binding.dnsInput.text.toString().trim()
        if (!isIpv4(dns)) {
            binding.dnsInput.error = "Masukkan IPv4 DNS yang valid, contoh 45.90.28.0"
            return
        }
        preferences.edit().putString(KEY_DNS, dns).apply()
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else connectNow()
    }

    private fun connectNow() {
        val dns = preferences.getString(KEY_DNS, NextDnsVpnService.DEFAULT_DNS)!!
        val intent = Intent(this, NextDnsVpnService::class.java)
            .setAction(NextDnsVpnService.ACTION_CONNECT)
            .putExtra(NextDnsVpnService.EXTRA_DNS, dns)
        startService(intent)
        refreshStatus()
        showMessage("NextDNS connecting...")
    }

    private fun disconnectNow() {
        startService(Intent(this, NextDnsVpnService::class.java).setAction(NextDnsVpnService.ACTION_DISCONNECT))
        refreshStatus()
        showMessage("NextDNS disconnected")
    }

    private fun refreshStatus() {
        val connected = NextDnsVpnService.isRunning
        binding.statusText.text = if (connected) "Status: Connected (${preferences.getString(KEY_DNS, NextDnsVpnService.DEFAULT_DNS)})" else "Status: Disconnected"
        binding.connectButton.isEnabled = !connected
        binding.disconnectButton.isEnabled = connected
    }

    private fun showMessage(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun isIpv4(value: String): Boolean {
        val parts = value.split('.')
        if (parts.size != 4) return false
        return parts.all { it.toIntOrNull()?.let { number -> number in 0..255 } == true }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    companion object {
        private const val PREFS = "nextdns_preferences"
        private const val KEY_DNS = "dns_server"
        fun start(context: Context) = context.startActivity(Intent(context, NextDnsActivity::class.java))
    }
}
