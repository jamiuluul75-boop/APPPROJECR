package top.niunaijun.blackboxa.nextdns;

import android.content.Intent;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.Arrays;

public class NextDnsVpnService extends VpnService {
    public static final String ACTION_CONNECT = "com.battle.launhcer.nextdns.CONNECT";
    public static final String ACTION_DISCONNECT = "com.battle.launhcer.nextdns.DISCONNECT";
    public static final String EXTRA_DNS = "dns";
    public static final String DEFAULT_DNS = "45.90.28.0";
    private static final String TAG = "NextDnsVpn";
    private static final String CHANNEL_ID = "nextdns_status";
    public static volatile boolean isRunning;

    private volatile boolean running;
    private ParcelFileDescriptor vpnInterface;
    private Thread worker;
    private String upstream = DEFAULT_DNS;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_DISCONNECT.equals(intent.getAction())) {
            stopVpn();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null) {
            String dns = intent.getStringExtra(EXTRA_DNS);
            if (dns != null && isIpv4(dns)) upstream = dns;
        }
        startVpn();
        return START_STICKY;
    }

    private synchronized void startVpn() {
        if (running) return;
        try {
            startForegroundNotification();
            InetAddress dns = InetAddress.getByName(upstream);
            Builder builder = new Builder()
                    .setSession("NextDNS")
                    .setMtu(1500)
                    .addAddress("10.77.0.2", 32)
                    .addRoute(upstream, 32)
                    .addDnsServer(dns);
            vpnInterface = builder.establish();
            if (vpnInterface == null) throw new IllegalStateException("VPN permission was not granted");
            running = true;
            isRunning = true;
            worker = new Thread(this::runDnsLoop, "NextDns-DnsLoop");
            worker.start();
            Log.i(TAG, "Connected to DNS upstream " + upstream);
        } catch (Exception e) {
            Log.e(TAG, "Unable to start NextDNS VPN", e);
            stopVpn();
        }
    }

    private void runDnsLoop() {
        byte[] buffer = new byte[32767];
        try (FileInputStream input = new FileInputStream(vpnInterface.getFileDescriptor());
             FileOutputStream output = new FileOutputStream(vpnInterface.getFileDescriptor())) {
            while (running) {
                int length = input.read(buffer);
                if (length > 0) forwardDns(buffer, length, output);
            }
        } catch (Exception e) {
            if (running) Log.e(TAG, "DNS loop stopped", e);
        }
    }

    private void forwardDns(byte[] packet, int length, FileOutputStream output) {
        if (length < 28 || (packet[0] & 0x0f) != 5 || (packet[9] & 0xff) != 17) return;
        int ipHeader = (packet[0] & 0x0f) * 4;
        int sourcePort = u16(packet, ipHeader);
        int destinationPort = u16(packet, ipHeader + 2);
        if (destinationPort != 53) return;
        int dnsOffset = ipHeader + 8;
        int dnsLength = length - dnsOffset;
        if (dnsLength < 12) return;
        byte[] query = Arrays.copyOfRange(packet, dnsOffset, length);
        try (DatagramSocket socket = new DatagramSocket()) {
            protect(socket);
            InetAddress server = InetAddress.getByName(upstream);
            socket.setSoTimeout(2500);
            socket.send(new DatagramPacket(query, query.length, server, 53));
            byte[] answer = new byte[4096];
            DatagramPacket response = new DatagramPacket(answer, answer.length);
            socket.receive(response);
            byte[] dnsAnswer = Arrays.copyOf(response.getData(), response.getLength());
            byte[] reply = buildUdpReply(packet, ipHeader, sourcePort, destinationPort, dnsAnswer);
            output.write(reply);
            output.flush();
        } catch (Exception e) {
            Log.w(TAG, "DNS query failed: " + e.getMessage());
        }
    }

    private byte[] buildUdpReply(byte[] request, int ipHeader, int sourcePort, int destinationPort, byte[] payload) {
        byte[] reply = new byte[ipHeader + 8 + payload.length];
        reply[0] = 0x45;
        reply[1] = 0;
        put16(reply, 2, reply.length);
        put16(reply, 4, 0);
        put16(reply, 6, 0x4000);
        reply[8] = 64;
        reply[9] = 17;
        System.arraycopy(request, 16, reply, 12, 4);
        System.arraycopy(request, 12, reply, 16, 4);
        put16(reply, 10, checksum(reply, 0, ipHeader));
        put16(reply, ipHeader, destinationPort);
        put16(reply, ipHeader + 2, sourcePort);
        put16(reply, ipHeader + 4, 8 + payload.length);
        put16(reply, ipHeader + 6, 0);
        System.arraycopy(payload, 0, reply, ipHeader + 8, payload.length);
        put16(reply, ipHeader + 6, udpChecksum(reply, ipHeader));
        return reply;
    }

    private static int udpChecksum(byte[] packet, int udpOffset) {
        long sum = 0;
        for (int i = 12; i < 20; i += 2) sum += u16(packet, i);
        sum += 17;
        sum += u16(packet, udpOffset + 4);
        for (int i = udpOffset; i < packet.length; i += 2) {
            int value = (packet[i] & 0xff) << 8;
            if (i + 1 < packet.length) value |= packet[i + 1] & 0xff;
            sum += value;
        }
        return fold(sum);
    }

    private static int checksum(byte[] data, int offset, int length) {
        long sum = 0;
        for (int i = offset; i < offset + length; i += 2) {
            int value = (data[i] & 0xff) << 8;
            if (i + 1 < offset + length) value |= data[i + 1] & 0xff;
            sum += value;
        }
        return fold(sum);
    }

    private static int fold(long sum) {
        while ((sum >> 16) != 0) sum = (sum & 0xffff) + (sum >> 16);
        return (int) (~sum) & 0xffff;
    }

    private static int u16(byte[] data, int offset) {
        return ((data[offset] & 0xff) << 8) | (data[offset + 1] & 0xff);
    }

    private static void put16(byte[] data, int offset, int value) {
        data[offset] = (byte) (value >>> 8);
        data[offset + 1] = (byte) value;
    }

    private static boolean isIpv4(String value) {
        try {
            return InetAddress.getByName(value) instanceof Inet4Address && value.indexOf(':') < 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    private synchronized void stopVpn() {
        running = false;
        isRunning = false;
        if (vpnInterface != null) {
            try { vpnInterface.close(); } catch (Exception ignored) {}
            vpnInterface = null;
        }
        worker = null;
        Log.i(TAG, "Disconnected");
    }

    private void startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "NextDNS", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        startForeground(1001, builder.setContentTitle("NextDNS active")
                .setContentText("DNS protection is connected")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setOngoing(true)
                .build());
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }
}
