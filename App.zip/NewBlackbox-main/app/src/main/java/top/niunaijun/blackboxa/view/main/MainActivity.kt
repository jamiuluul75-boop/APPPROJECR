package top.niunaijun.blackboxa.view.main

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.edit
import androidx.viewpager2.widget.ViewPager2
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.input.input
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackboxa.R
import top.niunaijun.blackboxa.app.AppManager
import top.niunaijun.blackboxa.databinding.ActivityMainBinding
import top.niunaijun.blackboxa.util.inflate
import top.niunaijun.blackboxa.view.apps.AppsFragment
import top.niunaijun.blackboxa.view.base.LoadingActivity
import top.niunaijun.blackboxa.view.fake.FakeManagerActivity
import top.niunaijun.blackboxa.view.setting.SettingActivity

class MainActivity : LoadingActivity() {

    private val viewBinding: ActivityMainBinding by inflate()

    private lateinit var mViewPagerAdapter: ViewPagerAdapter

    private val fragmentList = mutableListOf<AppsFragment>()

    companion object {
        private const val TAG = "MainActivity"
        private const val MLBB_PACKAGE = "com.mobile.legends"
        private const val MLBB_INDIA_PACKAGE = "com.mobiin.gp"
        private const val MCGG_PACKAGE = "com.mobilechess.gp"
        private const val EXTRA_SPACE_USER_ID = "space_user_id"
        private const val STORAGE_PERMISSION_REQUEST_CODE = 1001
        private const val VPN_PERMISSION_REQUEST_CODE = 1002

        fun start(context: Context, userId: Int = 0) {
            val intent = Intent(context, MainActivity::class.java)
            intent.putExtra(EXTRA_SPACE_USER_ID, userId)
            context.startActivity(intent)
        }
    }

    private val spaceUserId: Int by lazy { intent.getIntExtra(EXTRA_SPACE_USER_ID, 0) }
    private val isMcggRoom: Boolean get() = spaceUserId == 1

    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            super.onCreate(savedInstanceState)

            try {
                BlackBoxCore.get().onBeforeMainActivityOnCreate(this)
            } catch (e: Exception) {
                Log.e(TAG, "Error in onBeforeMainActivityOnCreate: ${e.message}")
            }

            setContentView(viewBinding.root)
            initToolbar(viewBinding.toolbarLayout.toolbar, R.string.app_name)
            val settingItem = viewBinding.toolbarLayout.toolbar.menu.add("SETTING")
            settingItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
            settingItem.setOnMenuItemClickListener {
                SettingActivity.start(this)
                true
            }
            ensureSelectedSpace()
            configureSpaceUi()
            initViewPager()
            initSpaceButtons()
            
            checkStoragePermission()

            
            checkVpnPermission()

            try {
                BlackBoxCore.get().onAfterMainActivityOnCreate(this)
            } catch (e: Exception) {
                Log.e(TAG, "Error in onAfterMainActivityOnCreate: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Critical error in onCreate: ${e.message}")
            
            showErrorDialog("Failed to initialize app: ${e.message}")
        }
    }

    private fun ensureSelectedSpace() {
        try {
            if (spaceUserId == 1) {
                BlackBoxCore.get().createUser(1)
            }
        } catch (e: Exception) {
            Log.d(TAG, "Space user already exists or is being initialized: ${e.message}")
        }
    }

    private fun configureSpaceUi() {
        viewBinding.mlbbCard.visibility = if (isMcggRoom) View.GONE else View.VISIBLE
        viewBinding.mlbbIndiaCard.visibility = if (isMcggRoom) View.GONE else View.VISIBLE
        viewBinding.mcggCard.visibility = if (isMcggRoom) View.VISIBLE else View.GONE
    }

    private fun checkStoragePermission() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                
                if (!android.os.Environment.isExternalStorageManager()) {
                    Log.w(TAG, "MANAGE_EXTERNAL_STORAGE permission not granted")
                    showStoragePermissionDialog()
                }
            } else {
                
                if (androidx.core.content.ContextCompat.checkSelfPermission(
                                this,
                                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ) != android.content.pm.PackageManager.PERMISSION_GRANTED ||
                                androidx.core.content.ContextCompat.checkSelfPermission(
                                        this,
                                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    Log.w(
                            TAG,
                            "Storage permissions not granted on Android ${android.os.Build.VERSION.SDK_INT}"
                    )
                    requestLegacyStoragePermission()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking storage permission: ${e.message}")
        }
    }

    private fun requestLegacyStoragePermission() {
        try {
            androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                            android.Manifest.permission.READ_EXTERNAL_STORAGE,
                            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    STORAGE_PERMISSION_REQUEST_CODE
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting storage permission: ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() &&
                            grantResults.all {
                                it == android.content.pm.PackageManager.PERMISSION_GRANTED
                            }
            ) {
                Log.d(TAG, "Storage permissions granted")
            } else {
                Log.w(TAG, "Storage permissions denied")
            }
        }
    }

    private fun showStoragePermissionDialog() {
        try {
            MaterialDialog(this).show {
                title(text = "Storage Permission Required")
                message(
                        text =
                                "This app needs 'All Files Access' permission to properly run sandboxed apps. Without this permission, some apps may not work correctly.\n\nPlease grant permission in the next screen."
                )
                positiveButton(text = "Grant Permission") { openAllFilesAccessSettings() }
                negativeButton(text = "Later") { Log.w(TAG, "User postponed storage permission") }
                cancelable(false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing storage permission dialog: ${e.message}")
        }
    }

    private fun openAllFilesAccessSettings() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                val intent =
                        Intent(
                                android.provider.Settings
                                        .ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
                        )
                intent.data = Uri.parse("package:$packageName")
                storagePermissionResult.launch(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening storage settings: ${e.message}")
            
            try {
                val intent =
                        Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                storagePermissionResult.launch(intent)
            } catch (e2: Exception) {
                Log.e(TAG, "Error opening fallback storage settings: ${e2.message}")
            }
        }
    }

    private val storagePermissionResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        if (android.os.Environment.isExternalStorageManager()) {
                            Log.d(TAG, "Storage permission granted!")
                        } else {
                            Log.w(TAG, "Storage permission still not granted")
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling storage permission result: ${e.message}")
                }
            }

    
    private fun checkVpnPermission() {
        try {
            val vpnIntent = VpnService.prepare(this)
            if (vpnIntent != null) {
                
                Log.d(TAG, "VPN permission not granted, requesting...")
                vpnPermissionResult.launch(vpnIntent)
            } else {
                
                Log.d(TAG, "VPN permission already granted")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking VPN permission: ${e.message}")
        }
    }

    private val vpnPermissionResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                try {
                    if (result.resultCode == RESULT_OK) {
                        Log.d(TAG, "VPN permission granted!")
                        
                    } else {
                        Log.w(TAG, "VPN permission denied by user")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling VPN permission result: ${e.message}")
                }
            }

    private fun showErrorDialog(message: String) {
        try {
            MaterialDialog(this).show {
                title(text = "Error")
                message(text = message)
                positiveButton(text = "OK") { finish() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing error dialog: ${e.message}")
            finish()
        }
    }

    private fun initViewPager() {
        try {
            fragmentList.clear()
            fragmentList.add(AppsFragment.newInstance(spaceUserId))

            mViewPagerAdapter = ViewPagerAdapter(this)
            mViewPagerAdapter.replaceData(fragmentList)
            viewBinding.viewPager.adapter = mViewPagerAdapter
            viewBinding.dotsIndicator.setViewPager2(viewBinding.viewPager)
            viewBinding.viewPager.registerOnPageChangeCallback(
                    object : ViewPager2.OnPageChangeCallback() {
                        override fun onPageSelected(position: Int) {
                            try {
                                super.onPageSelected(position)
                                showFloatButton(true)
                            } catch (e: Exception) {
                                Log.e(TAG, "Error in onPageSelected: ${e.message}")
                            }
                        }
                    }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error in initViewPager: ${e.message}")
        }
    }

    // MLBB Only - Launch dan Install button
    private fun initSpaceButtons() {
        try {
            if (isMcggRoom) {
                setupSpaceCard(viewBinding.btnLaunchMcgg, viewBinding.btnInstallMcgg, MCGG_PACKAGE, "MCGG Global")
            } else {
                setupSpaceCard(viewBinding.btnLaunch, viewBinding.btnInstall, MLBB_PACKAGE, "MLBB Global")
                setupSpaceCard(viewBinding.btnLaunchIndia, viewBinding.btnInstallIndia, MLBB_INDIA_PACKAGE, "MLBB India")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in initMlbbButtons: ${e.message}")
        }
    }

    private fun setupSpaceCard(
            launchButton: android.widget.Button,
            installButton: android.widget.Button,
            packageName: String,
            displayName: String
    ) {
        launchButton.setOnClickListener {
            try {
                showLoading()
                val launched = BlackBoxCore.get().launchApk(packageName, spaceUserId)
                if (!launched) {
                    hideLoading()
                    Toast.makeText(this, "$displayName belum diinstall. Silakan Install dulu.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                hideLoading()
                Log.e(TAG, "Error launching $displayName: ${e.message}")
                Toast.makeText(this, "Gagal launch $displayName: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
        installButton.setOnClickListener {
            installSpaceApp(packageName, displayName)
        }
    }

    private fun installSpaceApp(packageName: String, displayName: String) {
        try {
            val blackBox = BlackBoxCore.get()
            if (blackBox.isInstalled(packageName, spaceUserId)) {
                Toast.makeText(this, "$displayName sudah terpasang", Toast.LENGTH_SHORT).show()
                return
            }

            showLoading()
            Thread {
                val result = blackBox.installPackageAsUser(packageName, spaceUserId)
                runOnUiThread {
                    hideLoading()
                    if (result.success) {
                        Toast.makeText(this, "$displayName berhasil dipasang", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(
                                this,
                                "Gagal memasang $displayName: ${result.msg ?: "sumber aplikasi tidak ditemukan"}",
                                Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }.start()
        } catch (e: Exception) {
            hideLoading()
            Log.e(TAG, "Error installing $displayName: ${e.message}", e)
            Toast.makeText(this, "Gagal memasang $displayName: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Kept for compatibility with AppsFragment scroll hide/show (no-op sekarang)
    fun showFloatButton(show: Boolean) {
        // FAB sudah dihapus, fungsi ini dibiarkan kosong agar tidak crash
    }

    fun scanUser() {
        try {
            val userList = BlackBoxCore.get().users

            if (fragmentList.size == userList.size) {
                fragmentList.add(AppsFragment.newInstance(fragmentList.size))
            } else if (fragmentList.size > userList.size + 1) {
                fragmentList.removeLast()
            }

            mViewPagerAdapter.notifyDataSetChanged()
        } catch (e: Exception) {
            Log.e(TAG, "Error in scanUser: ${e.message}")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Tidak ada menu overflow pada launcher khusus MLBB.
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return super.onOptionsItemSelected(item)
    }
}
