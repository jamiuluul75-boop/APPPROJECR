package top.niunaijun.blackboxa.view.main

import android.os.Bundle
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackboxa.R
import top.niunaijun.blackboxa.util.inflate
import top.niunaijun.blackboxa.databinding.ActivitySpaceSelectorBinding
import androidx.appcompat.app.AppCompatActivity
import top.niunaijun.blackboxa.view.setting.SettingActivity

class SpaceSelectorActivity : AppCompatActivity() {
    private val viewBinding: ActivitySpaceSelectorBinding by inflate()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(viewBinding.root)

        viewBinding.btnSpaceMlbb.setOnClickListener { openSpace(0) }
        viewBinding.btnSpaceMcgg.setOnClickListener { openSpace(1) }
        viewBinding.btnSettings.setOnClickListener { SettingActivity.start(this) }
    }

    private fun openSpace(userId: Int) {
        try {
            if (userId == 1) {
                BlackBoxCore.get().createUser(1)
            }
        } catch (_: Exception) {
            // The user may already exist; the room remains usable.
        }
        MainActivity.start(this, userId)
        finish()
    }
}
