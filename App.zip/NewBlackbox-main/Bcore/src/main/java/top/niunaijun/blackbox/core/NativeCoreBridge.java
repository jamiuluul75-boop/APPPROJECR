package top.niunaijun.blackbox.core;

import android.util.Log;
import top.niunaijun.blackbox.app.BActivityThread;

/**
 * Routes native calls to the runtime owned by the active virtual room.
 * Ruang 0 / MLBB  -> NativeCore  (libblackbox.so + libVM.so)
 * Ruang 1 / MCGG  -> NevitecoreMcgg (libblackbox_mcgg.so + libMCGG.so)
 *
 * Critical: only the matching class is touched so the other room's mod-menu
 * .so is never loaded into the process.
 */
public final class NativeCoreBridge {
    private static final String TAG = "NativeCoreBridge";
    private static volatile Boolean sIsMcgg;

    private NativeCoreBridge() {}

    private static boolean isMcgg() {
        Boolean cached = sIsMcgg;
        if (cached != null) return cached;
        // userId is set in BActivityThread.initProcess BEFORE NativeCoreBridge.init()
        int userId = BActivityThread.getUserId();
        cached = (userId == 1);
        sIsMcgg = cached;
        Log.i(TAG, "Active room resolved: userId=" + userId + " -> " + (cached ? "MCGG (NevitecoreMcgg + libMCGG)" : "MLBB (NativeCore + libVM)"));
        return cached;
    }

    public static void init(int apiLevel) {
        if (isMcgg()) {
            NevitecoreMcgg.init(apiLevel);
        } else {
            NativeCore.init(apiLevel);
        }
    }

    public static void enableIO() {
        if (isMcgg()) NevitecoreMcgg.enableIO();
        else NativeCore.enableIO();
    }

    public static void addIORule(String targetPath, String relocatePath) {
        if (isMcgg()) NevitecoreMcgg.addIORule(targetPath, relocatePath);
        else NativeCore.addIORule(targetPath, relocatePath);
    }

    public static void hideXposed() {
        if (isMcgg()) NevitecoreMcgg.hideXposed();
        else NativeCore.hideXposed();
    }

    public static boolean disableHiddenApi() {
        return isMcgg() ? NevitecoreMcgg.disableHiddenApi() : NativeCore.disableHiddenApi();
    }

    public static boolean disableResourceLoading() {
        return isMcgg() ? NevitecoreMcgg.disableResourceLoading() : NativeCore.disableResourceLoading();
    }
}
